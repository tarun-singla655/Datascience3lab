 #importing all libraries
import pandas as pd  # data handling
import matplotlib.pyplot as plt  # for ploting
import statistics  # for finding mean , median , mode and other
from scipy.stats import pearsonr # for pearson correlation cofficient

#reading csv file
Data = pd.read_csv("landslide_data3.csv")  # reading files
d1 = Data.dtypes # for fetching attributes it will give pandas series
d1 = d1[2:] # skip first two as Data and stationid are not attributes



# problem 1..................................
Print("PROBLEM 1")
for index,value in d1.items():   # loop in d1 as it is series
    print("Attribute ", index,"........................")    # for particular Attribute
    values = sorted(Data[index]);      #sorting 
    print("Mean is ",sum(values)/len(values) )  #mean
    print("median is ", statistics.median(values));  #median
    print("mode is ",statistics.mode(values))   #mode
    print("minimum is ",min(values))   #minimum
    print("maximum is ",max(values))  #maximum
    print("Standarad deviation is ", statistics.stdev(values)) # standard deviation
    print("") 





# problem 2...............
Print("PROBLEM 2")
Array = ['rain', 'temperature']  # as we have to plot for rain and temperature so i made list 
for i in Array: #looping
    Values = Data[i]   #getting data  for attribute 
    print("Scatter plot with Attributes..............")
    for index,value in d1.items():
        if index==i:    #skipping attribute with itself
            continue   
        print('Scater of ' , i, ' with Attribute ',index)  # printing scatter plot between which we have to calculate
        plt.scatter(Values , Data[index]);  # ploting scatter plot
        s1 = "Scater plot with " + i
        plt.title(s1)  # title
        plt.xlabel(i)   # xlabel
        plt.ylabel(index)  #ylabel  
        plt.show()  
        print("")



#problem3..........................
Print("PROBLEM 3")
for i in Array:     # as we need correlation of rain and temperature
    Value1 = i;              
    print("Correlation Values with ",i)
    for index,value in d1.items():  # looping in  pandas series
        if index==i:      # as we done have to calcute correation cofficient with itself
            continue
        corr, _ = pearsonr(Data[i], Data[index])  # perason Correlation Cofficient
        print('correlation cofficient of ',i,' and ',index ,' is ', corr)  # printing
    print("")


# problem4............................
Print("PROBLEM 4")
Rain = Data['rain'] # histogram for rain
plt.hist(Rain , bins = 10)  # histogram
plt.title('Histogram of Rain')   #title
plt.show();
Moisture = Data['moisture']   # histogram for moisture
plt.hist(Moisture , bins = 10)    #ploting
plt.title('Histogram of Moisture')
plt.show();


#problem5...........................

Print("PROBLEM 5")
gkk = Data.groupby(['stationid'])    # group by station id it return dictionary

for x,y in gkk:   # particular stationID  looping in dictionary
    print("histogram of rain having station id ",x )
    Rain = y['rain'];  # extracting rain
    plt.hist(Rain);  # histogram ploting
    s1 = "historgram of rain for station with id " + x;
    plt.title(s1)
    plt.show()
    
    
    
    
#problem6

Print("PROBLEM 6")
Rain = Data['rain']  #rain data
Moisture = Data['moisture']    #moisture data
plt.boxplot(Rain)   # boxplot for rain
plt.title('Boxplot for Rain ')    #title
plt.show()    #ploting
plt.boxplot(Moisture)        # boxplot for moisture
plt.title('Boxplot for Moisture ')  #title
plt.show()
    


    
        
        
    
    
