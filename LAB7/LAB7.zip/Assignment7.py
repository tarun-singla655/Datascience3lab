#b19198 Tarun Singla 8872526396

import pandas as pd
import matplotlib.pyplot as plt
from sklearn import metrics
import numpy as np
from sklearn.cluster import KMeans
from sklearn.mixture import GaussianMixture
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import DBSCAN


K = 10
# calculate distortion measure of clustering
def disortion(centers,cluster,K):
    disortion = 0
    for i in range(K):
        for j in range(len(cluster[i][0])):
            disortion += (centers[0][i]-cluster[i][0][j])**2 + (centers[1][i]-cluster[i][1][j])**2
    return disortion
            
# purity score of cluster
def purity_score(y_true, y_pred):
  # compute contingency matrix (also called confusion matrix)
  contingency_matrix=metrics.cluster.contingency_matrix(y_true, y_pred)
  #print(contingency_matrix)
  # Find optimal one-to-one mapping between cluster labels and true labels
  row_ind, col_ind = linear_sum_assignment(-contingency_matrix)
  # Return cluster accuracy
  return contingency_matrix[row_ind,col_ind].sum()/np.sum(contingency_matrix)

# check whether point lies inside circle
def isinside(x,y,pointx,pointy,radius):
    return (pointx-x)**2 + (pointy-y)**2 - radius*radius <= 0;

# predicting label of test sample using dbscan
def dbscan_predict(model, X,radius):
    prediction = [-1]*500;
    for i in X.index:                 
        x1 = X.loc[i][0]
        y1 = X.loc[i][1]
        datapoints = []
        for j in range(len(model)):   # for all cluster looping 
            cnt = 0
            for k in range(len(model[j][0])):
                if( isinside(x1,y1,model[j][0][k],model[j][1][k],radius)):  # checking if particular point is inside circle
                    cnt+=1
            datapoints.append(cnt)
        index = -1
        maximum = 0
        for k in range(len(model)):    # assigning to the clustering with maximum points inside 
            if datapoints[k]>maximum:
                maximum = datapoints[k]
                index = k
        prediction[i] = index # storing it in a list  
    return prediction
            
test_data = pd.read_csv("mnist-tsne-test.csv")
train_data = pd.read_csv("mnist-tsne-train.csv")


# cluster stores data points for even cluster key is cluster from(0 , no_of_cluster-1) and values are cluster
# kmeans clustering for train data
def KMeansClusterTrain(X,K):
    kmeans = KMeans(n_clusters=K,random_state=42)   # kmeans clustering 
    kmeans.fit(X)  # fitting model
    predictions = kmeans.predict(X)   # predicting 
    cluster = {}
    centers = kmeans.cluster_centers_    # finding centers
    for i in range(K): 
        cluster[i] = [[],[]]
    for i in X.index:                      # storing different clusters 
        value = list(X.loc[i])
        cluster[predictions[i]][0].append(value[0])
        cluster[predictions[i]][1].append(value[1])
    print("Scatter plot of Kmeans clustering of train data with k value",K)
    print("")
    plt.figure(figsize=(9,7))
    for i in range(K):
        plt.scatter(cluster[i][0] , cluster[i][1] , label = "class " + str(i) )  # plotting the clusrter
    c1 = [x[0] for x in centers]
    c2 = [y[1] for y in centers]
    plt.scatter(c1,c2,color = "black" , label = "center")
    plt.xlabel("dimension 1")
    plt.ylabel("dimension 2")
    title = "k means clustetrring of train data with k value " + str(K)
    plt.title(title)
    plt.title("K Means clustering with k = 10")
    plt.legend()
    plt.show()
    purity = purity_score(list(train_data["labels"]),predictions);  # calculating the purity score
    print()
    print("purity score of kmeans clustering of train data with k value",K,"is",purity) 
    print("")
    return [c1,c2] , cluster # returning centers and cluster to calculate distortion value

# kmeans clustering for test data
# it is almost simillar as above 
# different is we are predicting for test samples
def kmeansTest(X,Y,K):
    kmeans = KMeans(n_clusters=K,random_state=42)  
    kmeans.fit(X)
    predictions = kmeans.predict(Y)   # we are predicting for test sample
    cluster = {}
    centers = kmeans.cluster_centers_
    for i in range(K): 
        cluster[i] = [[],[]]
    for i in Y.index:
        value = list(Y.loc[i])   # for test sammple
        cluster[predictions[i]][0].append(value[0])
        cluster[predictions[i]][1].append(value[1])
    print("Scatter plot of Kmeans clustering of test data with k value",K)
    print("")
    plt.figure(figsize=(9,7)) 
    for i in range(K):
        plt.scatter(cluster[i][0] ,cluster[i][1] , label = "class " + str(i) )  
    c1 = [x[0] for x in centers]
    c2 = [y[1] for y in centers]
    plt.scatter(c1,c2,color = "black" , label = "center")
    plt.xlabel("dimension 1")
    plt.ylabel("dimension 2")
    title = "k means clustetrring of test data with k value " + str(K)
    plt.title(title)
    plt.legend()
    plt.show()
    purity = purity_score(list(test_data["labels"]),predictions);
    print()
    print("purity score of kmeans clustering of test data with k value",K,"is",purity)
    print("")
    return [c1,c2] , cluster


# GMM clustering for test data it is same as earlier but we are using here GMM clustering 
def gmmTrain(X,K):
    gmm = GaussianMixture(n_components = K, random_state = 42)   # for guassian mixture model clustering 
    gmm.fit(X)
    predictions = gmm.predict(X)
    cluster = {}
    centers = gmm.means_
    for i in range(K):
        cluster[i] = [[],[]]
    for i in X.index:
        value = list(X.loc[i])
        cluster[predictions[i]][0].append(value[0])
        cluster[predictions[i]][1].append(value[1])
    print("Scatter plot of GMM clustering of train data with k value",K)
    print("")
    plt.figure(figsize=(9,7))
    for i in range(K):
        plt.scatter(cluster[i][0] , cluster[i][1] , label = "class " + str(i) )
    c1 = [x[0] for x in centers]
    c2 = [y[1] for y in centers]
    plt.scatter(c1,c2,color = "black" , label = "center")
    plt.xlabel("dimension 1")
    plt.ylabel("dimension 2")
    title = "GMM clustetrring of test data with k value " + str(K)
    plt.title(title)
    plt.legend()
    plt.show()
    purity = purity_score(list(train_data["labels"]),predictions);
    print()
    print("purity score of GMM clustering of train data with k value",K,"is",purity)
    print("")
    return [c1,c2] , cluster
    
#  GMM clustering for test data 
def gmmTest(X,Y,K):   
    gmm = GaussianMixture(n_components = K, random_state = 42)
    gmm.fit(X)
    predictions = gmm.predict(Y)  # we are using test data to predict 
    cluster = {}
    centers = gmm.means_
    for i in range(K):
        cluster[i] = [[],[]]
    for i in Y.index:
        value = list(Y.loc[i])
        cluster[predictions[i]][0].append(value[0])
        cluster[predictions[i]][1].append(value[1])
    print("Scatter plot of GMM clustering of test data with k value",K)
    print("")
    plt.figure(figsize=(9,7))
    for i in range(K):
        plt.scatter(cluster[i][0] , cluster[i][1] , label = "class " + str(i) )
    c1 = [x[0] for x in centers]
    c2 = [y[1] for y in centers]
    plt.scatter(c1,c2,color = "black" , label = "center")
    plt.xlabel("dimension 1")
    plt.ylabel("dimension 2")
    title = "GMM clustetrring of test data with k value " + str(K)
    plt.title(title)
    plt.legend()
    plt.show()
    purity = purity_score(list(test_data["labels"]),predictions);
    print()
    print("purity score of GMM clustering of test data with k value",K,"is",purity)
    print("")   
    

def dbscantrain(X,eps,min_sample,Has):
    dbscan_model=DBSCAN(eps=eps, min_samples=min_sample)   # dbscan for training data
    dbscan_model = dbscan_model.fit(X)
    predictions = dbscan_model.labels_
    No_of_cluster = max(predictions)+1
    if(No_of_cluster==0):   # it consists of only outliers then we have to print no clustering 
        print("No cluster with eps value",eps,"and min_samples", min_sample,"formed. It only contains oultiers")
        return {}
    outliers = []
    cluster = {}
    for i in range(No_of_cluster):
        cluster[i] = [[],[]]
    for i in X.index:
        if predictions[i] == -1:  # if particular data points is an outlier we dont need to consider in cluster
            continue
        value = list(X.loc[i])    
        cluster[predictions[i]][0].append(value[0])
        cluster[predictions[i]][1].append(value[1])
    if Has:  # it is for when we only want cluster in to use in test data 
        return cluster
    print("Scatter plot DBSCAN of train data with eps",eps,"and min_samples",min_sample)
    plt.figure(figsize=(9,7))
    for i in range(No_of_cluster):
        plt.scatter(cluster[i][0] , cluster[i][1] , label = "class " + str(i) )
    plt.xlabel("dimension 1")
    plt.ylabel("dimension 2")
    title = "DBSCAN of train data with eps " + str(eps) + "and min_samples " + str(min_sample)
    plt.title(title)
    plt.legend()
    plt.show()
    for i in range(len(predictions)):   # storing the outliers
        if(predictions[i]==-1):
            outliers.append(i)
    X1 = train_data   
    predictions = np.delete(predictions , outliers )  # removing outliers from predicted data
    X1 = X1.drop(outliers)
    X1 = X1.reset_index(drop = True)   # removing same from data
    purity = purity_score(list(X1["labels"]),predictions);  # calculating purity score
    print()
    print("purity score of DBSCAN of train data with eps",eps,"and min_samples",min_sample,"is",purity)
    print("")   
    return cluster
    

  # almost simillar to previous code 
def dbscantest(X,Y,eps,min_sample):
    cluster = dbscantrain(X,eps,min_sample,True)  # dbscan for train data to return clusters using cluster
    if (cluster=={}): # it means number of clusters are zero
        return 
    predictions = dbscan_predict(cluster,Y,eps);  #predicting test samples for dbscan 
    No_of_cluster = max(predictions)+1  # number of cluster
    outliers = []
    for i in range(No_of_cluster):
        cluster[i] = [[],[]]
    for i in Y.index:    
        if predictions[i] == -1:
            continue
        value = list(Y.loc[i])
        cluster[predictions[i]][0].append(value[0])
        cluster[predictions[i]][1].append(value[1])
    print("Scatter plot DBSCAN of test data with eps",eps,"and min_samples",min_sample)
    plt.figure(figsize=(9,7))
    for i in range(No_of_cluster):
        plt.scatter(cluster[i][0] , cluster[i][1] , label = "class " + str(i) )
    plt.xlabel("dimension 1")
    plt.ylabel("dimension 2")
    title = "DBSCAN of test data with eps " + str(eps) + "and min_samples " + str(min_sample)
    plt.title(title)
    plt.legend()
    plt.show()
    for i in range(len(predictions)):
        if(predictions[i]==-1):
            outliers.append(i)  
    Y1 = test_data
    predictions = np.delete(predictions , outliers )
    Y1 = Y1.drop(outliers)
    Y1 = Y1.reset_index(drop = True)
    purity = purity_score(list(Y1["labels"]),predictions);
    print()
    print("purity score of DBSCAN of test data with eps",eps,"and min_samples",min_sample,"is",purity)
    print("")   
    
    
X = train_data.loc[:, train_data.columns != 'labels']
Y = test_data.loc[:, test_data.columns != 'labels']
K = 10

# #question1 
print("................Question 1............")
print("KMeans clustering of train data with K = ",K)
print("")
#keam means clustering for train data k = 10
KMeansClusterTrain(X,K)
print("KMeans clustering of test data with K = ",K)
print("")
#keam means clustering for test data k = 10
kmeansTest(X,Y,K)

# #question 2
print("................Question 2............")
print("GMM clustering of train data with K = ",K)
print("")
# GMM means clustering for train data k = 10
gmmTrain(X,K)
print("GMM clustering of test data with K = ",K)
print("")
#GMM means clustering for test data k = 10
gmmTest(X,Y,K)


# #question 3
print("Question 3............")
print("DBSCAN of train data with eps 5 and min_samples 10")
print("")
# DBSCAN for train data with e = 5 and min_samples = 10
dbscantrain(X,5,10,False)
print("DBSCAN of test data with eps 5 and min_samples 10")
print("")
# DBSCAN for test data with e = 5 and min_samples = 10
dbscantest(X,Y,5,10)


differentkvalues = [2,5,8,12,18,20]
X = train_data.loc[:, train_data.columns != 'labels'] 
Y = test_data.loc[:, test_data.columns != 'labels']



print(".................BONUS QUESTIONS..............")
print("")
print("BONUS question 1................")
DistortionK = []
print("..........kmeans clustering of train for different values of k............")
# for different values for k 

# kmeans clustering 
for i in differentkvalues :
    centers,cluster = KMeansClusterTrain(X,i)  # kmeans clustering for different values for k
    distortion = disortion(centers,cluster,i)  # function to find distortion value for kmeans cluster 
    DistortionK.append(distortion)
print("finding value of k using elbow method ")
plt.plot(differentkvalues ,DistortionK)   # estimation of k using elbow method
plt.xlabel("value of k")
plt.ylabel("distortion")
plt.show()
print()
print("K means clustering of test data for different values of k")
# print()
for i in differentkvalues:
    kmeansTest(X,Y,i)  # for test data

# # GMM clustering for different values of k
differentkvalues = [2,5,8,12,18,20]
print("")
liklihood = []
print("..............GMM clustering of train for different values of k...........")
print()
for i in differentkvalues:
    centers,cluster = gmmTrain(X, i)   # GMM clustering for different values of k
    print("finding value of k using elbow method ")
    gmm = GaussianMixture(n_components = i, random_state = 42)   # for guassian mixture model clustering 
    gmm.fit(X)
    value = gmm.score_samples(X).sum()
    liklihood.append(value)
plt.plot(differentkvalues ,liklihood)
plt.xlabel("value of k")
plt.ylabel("liklihood")
plt.show()
print()
print("GMM clustering of test data for different values of k")
print()
for i in differentkvalues :
    gmmTest(X, Y, i)

# # print()
# # print("BONUS question 2................")
Epsilon = [1,5,10]
Min_Samples = [1,10,30,50]                                # dbscan by varying eps
print(".....DBSCAN of train and test data with min_samples 10 and varying eps........")
for i in Epsilon:
    print("DBSCAN For train data data with eps ",i)
    dbscantrain(X,i,10,False)                     # dbscan for training with varying eps
    print("DBSCAN For test data data with eps ",i)  
    dbscantest(X,Y,i,10)                # dbscan for test data with varying epsilo
    
# print()
# print("..........DBSCAN of train and test data eps and varying min_samples............")
for i in Min_Samples:   # varying min_samples
#     print("DBSCAN For train data data with min_samples ",i)
#     dbscantrain(X,5,i,False)  # dbscan for training data with varying min_samples
#     print("DBSCAN For test data data with min_samples ",i)
      dbscantest(X,Y,5,i)   # dbscan for test data with varying min_samples

    
    